To complete the project 2, referred below sites If I got stuck some place, the source(s) below helped me:

Python documentation : https://docs.python.org/3/library/

Pandas Documentation: https://www.learnpython.org/en/Pandas_Basics

and Udacity Practice Solutions help me a lot. 

Practice IDE:
I used Anaconda (Spyder 4.0.1) IDE.
Udacity Workspace. 
 